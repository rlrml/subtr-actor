use boxcars::ParserBuilder;
use subtr_actor::ReplayDataCollector;
use subtr_actor::ballchasing::compare_replay_against_ballchasing_json;

fn main() -> anyhow::Result<()> {
    let data = std::fs::read("test.replay")?;
    let ballchasing = std::path::Path::new("b75117e4-a56f-4ad9-8195-f3284574f5b4.json");
    let replay = ParserBuilder::new(&data)
        .must_parse_network_data()
        .on_error_check_crc()
        .parse()?;

    let replay_data = ReplayDataCollector::new()
        .get_replay_data(&replay)
        .map_err(|e| e.variant)?;

    let report = compare_replay_against_ballchasing_json(
        "test.replay",
        ballchasing,
        &Default::default()
    )?;

    println!("Report: {} {:#?}", report.is_match(), report.mismatches());
    
    // println!("{}", replay_data.as_json()?);
    Ok(())
}